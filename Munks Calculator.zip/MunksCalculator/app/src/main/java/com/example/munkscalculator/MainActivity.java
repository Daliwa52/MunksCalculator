package com.example.munkscalculator;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import net.objecthunter.exp4j.Expression;
import net.objecthunter.exp4j.ExpressionBuilder;

public class MainActivity extends AppCompatActivity {

    private TextView computationText, resultText;
    private StringBuilder computation = new StringBuilder();
    private boolean isResultDisplayed = false;
    private boolean openParenthesis = true; // Track opening/closing parentheses

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        computationText = findViewById(R.id.computationText);
        resultText = findViewById(R.id.resultText);

        resetCalculator(); // Initialize with an empty state
        initializeButtonListeners(); // Set up button behavior
    }

    private void initializeButtonListeners() {
        int[] numberButtons = {
                R.id.btn0, R.id.btn1, R.id.btn2, R.id.btn3, R.id.btn4,
                R.id.btn5, R.id.btn6, R.id.btn7, R.id.btn8, R.id.btn9
        };

        // Operator buttons (including dot and power)
        int[] operatorButtons = {
                R.id.btnAdd, R.id.btnSubtract, R.id.btnMultiply, R.id.btnDivide, R.id.btnPower, R.id.btnDot
        };

        // Handle number buttons
        for (int id : numberButtons) {
            findViewById(id).setOnClickListener(view -> {
                if (isResultDisplayed) {
                    computation.setLength(0); // Clear computation if result was displayed
                    isResultDisplayed = false;
                    resultText.setText(""); // Clear resultText view
                }
                computation.append(((Button) view).getText());
                computationText.setText(computation.toString());
            });
        }

        // Handle operator buttons
        for (int id : operatorButtons) {
            findViewById(id).setOnClickListener(view -> {
                String operator = ((Button) view).getText().toString();

                // Allow operator only if the last character is valid (not another operator or an empty input)
                if (computation.length() > 0 && isOperatorAllowed(computation.toString())) {
                    computation.append(operator);
                    computationText.setText(computation.toString());
                }
            });
        }

        // Parentheses button
        findViewById(R.id.btnParentheses).setOnClickListener(view -> {
            if (isResultDisplayed) {
                computation.setLength(0); // Clear computation if result was displayed
                isResultDisplayed = false;
                resultText.setText(""); // Clear resultText view
            }
            if (openParenthesis) {
                computation.append("(");
            } else {
                computation.append(")");
            }
            openParenthesis = !openParenthesis; // Toggle state
            computationText.setText(computation.toString());
        });

        // Equals button
        findViewById(R.id.btnEquals).setOnClickListener(view -> {
            try {
                String expressionStr = computation.toString();

                // Check for valid expression before evaluation
                if (isValidExpression(expressionStr)) {
                    Expression expression = new ExpressionBuilder(expressionStr).build();
                    double result = expression.evaluate();

                    computationText.setText(""); // Clear the computation view
                    resultText.setText(String.valueOf(result)); // Display the result
                    computation.setLength(0);
                    computation.append(result); // Store result for further computations
                    isResultDisplayed = true;
                } else {
                    resultText.setText("Invalid Expression"); // Show error for invalid input
                }
            } catch (Exception e) {
                resultText.setText("Error"); // Generic error fallback
                computation.setLength(0); // Clear invalid computation
            }
        });

        // Clear button ("C")
        findViewById(R.id.btnC).setOnClickListener(view -> resetCalculator());

        // Backspace button
        findViewById(R.id.btnBackspace).setOnClickListener(view -> {
            if (computation.length() > 0) {
                computation.deleteCharAt(computation.length() - 1); // Remove last character
                computationText.setText(computation.length() > 0 ? computation.toString() : "");
            } else {
                resetCalculator(); // Reset if empty
            }
        });
    }

    private void resetCalculator() {
        computation.setLength(0);
        computationText.setText("");
        resultText.setText("");
        isResultDisplayed = false;
        openParenthesis = true; // Reset parentheses tracking
    }

    private boolean isValidExpression(String expression) {
        if (expression.isEmpty()) {
            return false;
        }

        // Check for balanced parentheses
        int openParentheses = 0;
        for (char c : expression.toCharArray()) {
            if (c == '(') openParentheses++;
            if (c == ')') openParentheses--;
            if (openParentheses < 0) return false; // Closing parentheses without matching opening
        }
        if (openParentheses != 0) return false; // Unbalanced parentheses

        // Check for invalid trailing characters (e.g., operators)
        char lastChar = expression.charAt(expression.length() - 1);
        return Character.isDigit(lastChar) || lastChar == ')';
    }

    private boolean isOperatorAllowed(String expression) {
        char lastChar = expression.charAt(expression.length() - 1);
        // Allow operator if the last character is a number or closing parenthesis
        return Character.isDigit(lastChar) || lastChar == ')';
    }
}
